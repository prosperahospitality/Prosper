import React from 'react';
import AddBlog from '@/app/admin/blog/Addblog';


const adminPage = () => {


  return (
    <>
    <AddBlog />
    </>
  )
}

export default adminPage;