'use client'
import { useState } from 'react';
import AdminChat from '@/_components/ChatSupport/AdminChat';

const ChatPage = () => {

  return (
    <div>
      <AdminChat />
    </div>
  );
};

export default ChatPage;
