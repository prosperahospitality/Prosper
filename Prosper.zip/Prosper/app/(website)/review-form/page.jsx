"use client";
import React, { useEffect, useState } from "react";
import ReviewForm from "@/_components/ReviewForm/ReviewForm";

const ReviewFormm = () => {


    return (
        <>
        <ReviewForm />
        </>
    );
};

export default ReviewFormm;
