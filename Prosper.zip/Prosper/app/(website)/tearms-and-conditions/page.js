import React from 'react'
import TearmsAndConditions from '@/_components/TearmsAndConditions/TearmsAndConditions'

const page = () => {
  return (
    <TearmsAndConditions />
  )
}

export default page