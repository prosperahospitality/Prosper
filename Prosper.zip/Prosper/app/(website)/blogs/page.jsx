import React from 'react'
import Blogs from '@/_components/Blogs/Blogs'

const blogs = () => {
  return (
    <Blogs />
  )
}

export default blogs