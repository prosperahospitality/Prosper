'use client'
import { useState } from 'react';
import SenderChat from '@/_components/ChatSupport/Chat';

const ChatPage = () => {

  return (
    <div>
      <SenderChat />
    </div>
  );
};

export default ChatPage;
