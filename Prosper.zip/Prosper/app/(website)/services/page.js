import React from 'react'
import OurServices from '@/_components/OurServices/OurServices'

const ourservices = () => {
  return (
    <OurServices />
  )
}

export default ourservices