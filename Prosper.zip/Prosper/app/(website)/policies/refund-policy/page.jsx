import React from 'react'
import RefundPolicy from '@/_components/Policies/RefundPolicy/RefundPolicy'

const refundpolicy = () => {
  return (
    <RefundPolicy />
  )
}

export default refundpolicy