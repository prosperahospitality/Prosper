import React from 'react'
import PrivacyPolicy from '@/_components/Policies/PrivacyPolicy/PrivacyPolicy'

const privacypolicy = () => {
  return (
    <PrivacyPolicy />
  )
}

export default privacypolicy