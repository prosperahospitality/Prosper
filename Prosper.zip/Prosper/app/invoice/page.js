import React from 'react'
import InvoicePage from '@/_components/Employee/Invoice/Invoice'

const page = () => {
  return (
        <InvoicePage />
  )
}

export default page